<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of settings
 *
 * @author ayman
 */
class CRDN_CFP_Settings {
	
	protected $_slug = 'crdn-cfp-global-settings';
	protected $_global_settings = array( 'post' => array(), 'page' => array() );

	public function __construct() {
		$this->load_global_settings();
	}
	
	public function get_option( $option, $default ) {
		
		return $default;
	}
	
	public function load_global_settings() {
		$this->_global_settings = apply_filters( 'crdn_cfp_fetch_global_settings', get_option( $this->_slug, $this->_global_settings ) );
	}
	
	public function default_global_settings( $settings ) {
		$settings['enabled'] = isset( $settings['enabled'] ) ? $settings['enabled'] : true;
		$settings['page'] = wp_parse_args( $settings['page'], array(
			
		) );
	}
}
