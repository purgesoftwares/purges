<?php
/**
 * Plugin Name: CircleFlip Portfolio
 * Description: adds the portfolio feature for the "Circleflip" theme
 * Version: 1.1.0
 * Author: Creiden
 * Author URI: http://creiden.com
 * License: GPL2
 */

define( 'CRDN_CFP_ROOT', dirname( __FILE__ ) );

function crdn_cfp_autoloader( $class ) {
	if ( false !== strpos( $class, 'CRDN_CFP_' ) ) {
		$class = strtolower( $class );
		include CRDN_CFP_ROOT
				. DIRECTORY_SEPARATOR
				. 'classes' 
				. DIRECTORY_SEPARATOR 
				. str_replace( '_', DIRECTORY_SEPARATOR, $class )
				. '.php';
	}
}

spl_autoload_register( 'crdn_cfp_autoloader' );


if ( ! function_exists( 'circleflip_get_portfolio_meta' ) ) {

	function circleflip_get_portfolio_meta( $post_id, $meta_key, $default = false ) {
		if ( empty( $post_id ) || empty( $meta_key ) ) {
			return $default;
		}
		global $circleflip_portfolio;
		$meta_data = $circleflip_portfolio->get_meta( $post_id );
		return $meta_data[ $meta_key ] ? $meta_data[ $meta_key ] : $default;
	}
}

if ( ! function_exists( 'circleflip_get_portfolio_page_meta' ) ) {

	function circleflip_get_portfolio_page_meta( $post_id, $meta_key = '', $default = false ) {
		if ( empty( $post_id ) ) {
			return $default;
		}
		global $circleflip_portfolio;
		$meta_data = $circleflip_portfolio->get_page_meta( $post_id );
		if ( empty( $meta_key ) )
			return $meta_data;
		return $meta_data[ $meta_key ] ? $meta_data[ $meta_key ] : $default;
	}
}

if ( ! function_exists( 'circleflip_get_portfolio_categories' ) ) {

	function circleflip_get_portfolio_categories( $post_id = null, $args = array() ) {
		global $circleflip_portfolio;
		$cats = $circleflip_portfolio->get_categories( $post_id, $args );
		return ! is_wp_error( $cats ) ? $cats : array();
	}
}

if ( ! function_exists( 'circleflip_get_portfolio_tags' ) ) {

	function circleflip_get_portfolio_tags( $post_id = null, $args = array() ) {
		global $circleflip_portfolio;
		$tags = $circleflip_portfolio->get_tags( $post_id, $args );
		return ! is_wp_error( $tags ) ? $tags : array();
	}
}

if ( ! function_exists( 'circleflip_get_portfolio_items' ) ) {

	function circleflip_get_portfolio_items( $args = array() ) {
		global $circleflip_portfolio;
		return $circleflip_portfolio->get_portfolio_items( $args );
	}
}

global $circleflip_portfolio;

if ( is_admin() ) {
	$circleflip_portfolio = new CRDN_CFP_Admin;
} else {
	$circleflip_portfolio = new CRDN_CFP_Frontend;
}