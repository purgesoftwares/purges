<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of admin
 *
 * @author ayman
 */
class CRDN_CFP_Admin extends CRDN_CFP_Base {
	
	public function __construct() {
		parent::__construct();
		add_filter( "manage_taxonomies_for_{$this->_cpt_name}_columns", array( $this, 'custom_tax_columns' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_box' ) );
		add_action( 'save_post', array( $this, 'save_meta_data' ) );
		add_action( 'save_post', array( $this, 'save_page_meta_data' ) );
	}
	
	/**
	 * enqueue metabox js only on portfolio edit screens
	 *
	 * @todo find a cleaner way to check for correct screen
	 *
	 * @global stdClass $current_screen
	 * @param string $hook
	 */
	public function admin_enqueue_scripts( $hook ) {
		global $current_screen;
		if ( isset( $current_screen->base )
				&& 'post' == $current_screen->base
				&& isset( $current_screen->post_type )
				&& $this->_cpt_name == $current_screen->post_type
		) {
			wp_enqueue_script( 'circleflip-portfolio-admin' );
		}
	}
	
	/**
	 * registers category & tag custom taxs to show in portfolio
	 * custom post type list table as what happens in normal post
	 *
	 * hooked: manage_taxonomies_for_{$this->_cpt_name}_columns,
	 *		availabel since wp 3.5.0
	 * @param array $taxonomies
	 * @return array
	 */
	public function custom_tax_columns( $taxonomies ) {
		array_push( $taxonomies, $this->_cat_name, $this->_tag_name );
		return $taxonomies;
	}
	
	/* ======================================================================= *
	 *                                METABOXES                                *
	 * ======================================================================= */

	/**
	 * register meta box for portfolio custom post type
	 */
	public function add_meta_box() {
		$args = array(
			'id'             => "$this->_cpt_name-mb",
			'title'          => 'Portfolio Meta',
			'callback'       => array($this, 'render_meta_box'),
			'screen'         => $this->_cpt_name,
			'context'        => 'normal',
			'priority'       => 'high',
			'callback_args'  => NULL
		);
		extract( $args );

		add_meta_box( $id, $title, $callback, $screen, $context, $priority, $callback_args ); //metabox for posts

		$layout_mb_args = array(
			'id'             => "$this->_cpt_name-layout-mb",
			'title'          => 'Portfolio Layout',
			'callback'       => array($this, 'render_layout_meta_box'),
			'screen'         => 'page',
			'context'        => 'normal',
			'priority'       => 'high',
			'callback_args'  => NULL
		);

		extract( $layout_mb_args );

		add_meta_box( $id, $title, $callback, $screen, $context, $priority, $callback_args ); //metabox for posts
	}
	/**
	 * render `Portfolio Meta` metabox
	 *
	 * @global WP_Post $post
	 * @todo 7antef
	 * @todo handle default values, i.e: only save the diff
	 */
	public function render_meta_box() {
		global $post;
		$data = $this->get_meta( $post->ID );
		wp_nonce_field( $this->_cpt_name, "$this->_cpt_name[_nonce]" );
		?>
		<p>Display Layout</p>
		<label class="screen-reader-text">display layout</label>
		<p>
			<label>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[layout]"
					   value="1"
					   <?php checked( $data['layout'], 1 ) ?>>
				Layout 1
			</label>
			<label>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[layout]"
					   value="2"
					   <?php checked( $data['layout'], 2 ) ?>>
				Layout 2
			</label>
		</p>
		<p>
			<label>
				<b>Project Details Title </b>
				<br>
				<input type="text" 
					   class="regular-text" 
					   placeholder="ex: project details"
					   name="<?php echo $this->_cpt_name ?>[project_details_title]"
					   value="<?php echo ! empty( $data['project_details_title'] ) ? $data['project_details_title'] : '' ?>">
			</label>
		</p>
		<p><b>Project Details</b></p>
		<table class="form-table" id="project-details">
			<tbody>
				<?php foreach ( $data['project_details'] as $row ) : ?>
					<tr>
						<td>
							<input type="text"
								   name="<?php echo $this->_cpt_name ?>[project_details][key][]"
								   value="<?php echo $row['key'] ?>">
						</td>
						<td>
							<input type="text"
								   name="<?php echo $this->_cpt_name ?>[project_details][value][]"
								   value="<?php echo $row['value'] ?>">
						</td>
						<td><input type="button" class="button circleflip-remove" value="remove"></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
			<thead>
				<tr>
					<th>Key</th>
					<th>Value</th>
					<th style="width: 10%"></th>
				</tr>
			</thead>
			<tfoot>
				<tr>
					<th><input type="text" class="circleflip-projectdetail-key" placeholder="key"></th>
					<th><input type="text" class="circleflip-projectdetail-value" placeholder="value"></th>
					<th><input type="button" class="button" id="circleflip-add" value="Add"></th>
				</tr>
			</tfoot>
		</table>
		<script id="tmpl-project-detail" type="text/template">
			<tr>
				<td>
					<input type="text"
						   name="<?php echo $this->_cpt_name ?>[project_details][key][]"
						   value="<%= data.key %>">
				</td>
				<td>
					<input type="text"
						   name="<?php echo $this->_cpt_name ?>[project_details][value][]"
						   value="<%= data.value %>">
				</td>
				<td><input type="button" class="button circleflip-remove" value="remove"></td>
			</tr>
		</script>
		<?php
	}

	public function render_layout_meta_box() {
		global $post;
		$data = $this->get_page_meta( $post->ID );
		$sidebars = cr_get_option( 'sidebars', array() );
		wp_nonce_field( $this->_cpt_name, "$this->_cpt_name[_nonce]" );
		?>
		<p>Layout</p>
		<p>
			<label>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[style]"
					   value="grid"
					   data-fd-handle="layout"
					   <?php checked( $data['style'], 'grid' ) ?>>
				Grid
			</label>
			<label>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[style]"
					   value="masonry"
					   data-fd-handle="layout"
					   <?php checked( $data['style'], 'masonry' ) ?>>
				Masonry
			</label>
			<label>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[style]"
					   value="checkers"
					   data-fd-handle="layout"
					   <?php checked( $data['style'], 'checkers' ) ?>>
				Checkers
			</label>
		</p>
		<div data-fd-rules='["layout:!equal:checkers"]'>
		<p>Text Position</p>
		<p>
			<label>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[text_position]"
					   value="in"
					   data-fd-handle="textPosition"
					   <?php checked( $data['text_position'], 'in' ) ?>>
				Text inside the hover
			</label>
			<label>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[text_position]"
					   value="under"
					   data-fd-handle="textPosition"
					   <?php checked( $data['text_position'], 'under' ) ?>>
				Text under the image
			</label>
		</p>
		</div>
		<p>Hover Style</p>
		<p class="cf-group">
			<label>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[hover-style]"
					   value="1"
					   <?php checked( $data['hover-style'], 1 ) ?>>
				White
			</label>
			<label>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[hover-style]"
					   value="2"
					   <?php checked( $data['hover-style'], 2 ) ?>>
				Red with horizontal icons
			</label>
			<label data-fd-rules='["textPosition:!equal:under", "layout:!equal:checkers"]'>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[hover-style]"
					   value="3"
					   <?php checked( $data['hover-style'], 3 ) ?>>
				Red with diagonal icons
			</label>
			<label data-fd-rules='["textPosition:!equal:under", "layout:!equal:checkers"]'>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[hover-style]"
					   value="4"
					   <?php checked( $data['hover-style'], 4 ) ?>>
				Red with post excerpt
			</label>
		</p>
		<p>Columns</p>
		<p class="cf-group">
			<label data-fd-rules='["layout:regex:checkers|grid"]'>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[columns]"
					   value="1"
					   <?php checked( $data['columns'], '1' ) ?>>
				1
			</label>
			<label data-fd-rules='["layout:regex:masonry|grid"]'>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[columns]"
					   value="2"
					   <?php checked( $data['columns'], '2' ) ?>>
				2
			</label>
			<label data-fd-rules='["layout:regex:masonry|grid"]'>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[columns]"
					   value="3"
					   <?php checked( $data['columns'], '3' ) ?>>
				3
			</label>
			<label data-fd-rules='["layout:regex:masonry|grid", "withSidebar:equal:none"]'>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[columns]"
					   value="4"
					   <?php checked( $data['columns'], '4' ) ?>>
				4
			</label>
		</p>
		<p>Sidebar</p>
		<p>
			<label>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[sidebar]"
					   value="left"
					   data-fd-handle="withSidebar"
					   <?php checked( $data['sidebar'], 'left' ) ?>>
				Left
			</label>
			<label>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[sidebar]"
					   value="right"
					   data-fd-handle="withSidebar"
					   <?php checked( $data['sidebar'], 'right' ) ?>>
				Right
			</label>
			<label>
				<input type="radio"
					   name="<?php echo $this->_cpt_name ?>[sidebar]"
					   value="none"
					   data-fd-handle="withSidebar"
					   <?php checked( $data['sidebar'], 'none' ) ?>>
				None
			</label>
		</p>
		<p data-fd-rules='["withSidebar:!equal:none"]'>
			<label>
				Which sidebar?
				<select name="<?php echo $this->_cpt_name ?>[which_sidebar]">
					<option value="" <?php selected($data['which_sidebar'], '') ?>>select a sidebar</option>
				<?php foreach ( $sidebars as $sidebar ) : ?>
					<option value="<?php echo $sidebar ?>" <?php selected($data['which_sidebar'], $sidebar) ?>>
						<?php echo $sidebar ?>
					</option>
				<?php endforeach; ?>
				</select>
			</label>
		</p>
		<script>
		(function($){
			$(document).ready(function(){
				var togglePortfolioLayoutMetabox = function(){
					$("#circleflip-portfolio-layout-mb").toggle('templates/template-portfolio.php' == $('#page_template').val());
				};
				togglePortfolioLayoutMetabox();
				$("#page_template").on('change', togglePortfolioLayoutMetabox);
				$("#circleflip-portfolio-layout-mb")
					.crdnFieldDependency()
                	.off( 'change.crdnfd' )
                	.on( 'change.crdnfd', '[data-fd-handle]', function() {
                    	$("#circleflip-portfolio-layout-mb")
							.crdnFieldDependency( 'run' )
							.find('.cf-group')
							.each(function(){
								// check if the users choise is still viable
								if ( $(this).find(':radio:checked:visible').length == 0 ) {
									$(this).find(':radio:visible:first').prop('checked', true);
								}
							});
						
                	} );
			});
		}(jQuery));
		</script>
		<?php
	}

	/**
	 * saves data from `Portfolio Meta` metabox
	 *
	 * @param type $post_id
	 * @return void | int $post_id if we didn't do a save
	 */
	public function save_meta_data( $post_id ) {
		if ( $this->_cpt_name != get_post_type( $post_id )
				|| ! isset( $_POST[ $this->_cpt_name ] ) // we have data
				|| ! wp_verify_nonce( $_POST[ $this->_cpt_name ]['_nonce'], $this->_cpt_name )
				|| defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE
				|| ! current_user_can( 'edit_post', $post_id )
		) {
			return $post_id;
		}

		$data = array(
			'layout'				 => ( int ) $_POST[$this->_cpt_name]['layout'] === 1 ? 1 : 2,
			'project_details_title'	 => ! empty( $_POST[$this->_cpt_name]['project_details_title'] ) ? $_POST[$this->_cpt_name]['project_details_title'] : ''
		);
		//@todo clean this mess
		if ( ! empty( $_POST[$this->_cpt_name]['project_details']['key'] ) ) {
			$project_keys = array_map( 'trim', $_POST[$this->_cpt_name]['project_details']['key'] );
			$project_values = array_map( 'trim', $_POST[$this->_cpt_name]['project_details']['value'] );
			$data['project_details'] = array_map( null, $project_keys, $project_values );
			$data['project_details'] = array_map(
					'array_combine',
					array_fill( 0, count( $data['project_details'] ), array('key', 'value') ),
					$data['project_details']
			);
		}
		update_post_meta( $post_id, "_{$this->_cpt_name}-meta", $data );
	}

	public function save_page_meta_data( $post_id ) {
		if ( ! isset( $_POST[ $this->_cpt_name ] ) // we have data
				|| ! wp_verify_nonce( $_POST[ $this->_cpt_name ]['_nonce'], $this->_cpt_name )
				|| defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE
				|| ! current_user_can( 'edit_pages' )
				|| 'templates/template-portfolio.php' !== get_page_template_slug( $post_id )
		) {
			return $post_id;
		}
		$data = array(
			'hover-style'	 => ( int ) $_POST[$this->_cpt_name]['hover-style'],
			'sidebar'		 => $_POST[$this->_cpt_name]['sidebar'],
			'which_sidebar'  => $_POST[$this->_cpt_name]['which_sidebar'],
			'style'			 => $_POST[$this->_cpt_name]['style'],
			'columns'		 => ( int ) $_POST[$this->_cpt_name]['columns'],
			'text_position'  => $_POST[$this->_cpt_name]['text_position'],
		);
		update_post_meta( $post_id, "_{$this->_cpt_name}-meta", $data );
	}
	
	// add page metabox
	// add project metabox
	// add settings page
	
	// display taxonomy columns in cpt table
}
