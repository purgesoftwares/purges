<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of frontend
 *
 * @author ayman
 */
class CRDN_CFP_Frontend extends CRDN_CFP_Base {

	public function __construct() {
		parent::__construct();
		add_filter( 'taxonomy_template', array( $this, 'intercept_tax_template' ) );
		add_action( 'pre_get_posts', array( $this, 'modify_query' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'wp_enqueue_scripts' ) );
		add_filter( 'excerpt_more', array( $this, 'excerpt_more' ) );

		add_filter( 'circleflip-portfolio-columns-template', array( $this, 'columns_template' ) );
		add_filter( 'circleflip-portfolio-single-template', array( $this, 'single_template' ) );
		add_action( 'post_class', array( $this, 'handle_portfolio_columns' ), 10, 3 );

		add_filter( 'post_thumbnail_size', array( $this, 'correct_image_size' ) );
//		add_filter( 'post_thumbnail_html', array( $this, 'dummy_thumbnail' ), 10, 5 );

		add_filter( 'circleflip_post_format_meta', array( $this, 'gallery_layout' ), 10, 5 );
		add_filter( 'circleflip_post_format_media_size', array( $this, 'correct_media_size' ), 10, 5 );
		add_filter( 'circleflip_post_format_html', array( $this, 'handle_post_formats' ), 10, 6 );

		// add_action( 'wp_footer', array( $this, 'print_queued_media' ) );
	}
	
	/**
	 * enqueue scripts on portfolio pages
	 */
	public function wp_enqueue_scripts() {
		if ( $this->is_portfolio_page() ) {
			if ( ! is_single() ) {
				wp_enqueue_script( 'circleflip-portfolio-front' );
				if ( 1 == $this->get_columns_num() ) {
					$this->l10n['layout'] = 'list';
				} else {
					$this->l10n['layout'] = 'grid';
				}
				$layout_map = array(
					'grid'		 => 'fitRows',
					'masonry'	 => 'masonry',
					'checkers'	 => 'straightDown'
				);
				$this->l10n['layoutMode'] = $layout_map[$this->get_page_style()];
				wp_localize_script( 'circleflip-portfolio-front', 'circleflipMixitupConfig', $this->l10n );
			}
			wp_enqueue_style( 'portfolioStyle' );
			wp_enqueue_style('prettyStyle');
			wp_enqueue_script('pretty');
			$page_style = $this->get_page_style();
//			if($page_style == 'masonry') {
//				wp_enqueue_script( 'masonrySectionJS' );
//				wp_enqueue_script( 'masonrySectionCustomJS' );
//			}
		}
	}
	
	public function print_queued_media() {
		if ( ! empty( $this->_media_queue ) ) {
			?>
			<div id='cf-media-modals'>
				<?php foreach( $this->_media_queue as $post_id => $media ) : ?>
					<div id="postsquarered-<?php echo $post_id ?>" class="portfolioPageModal modal hide fade cf-<?php echo $media['format'] ?>">
						<div class="modal-body">
							<?php echo $media['content'] ?>
						 </div>
					</div>
				<?php endforeach; ?>
			</div>
			<?php
		}
	}
	
	/**
	 * load archive-circleflip-portfolio.php for cat & tax pages
	 *
	 * @todo deprecate
	 *
	 * @param string $location
	 * @return string
	 */
	public function intercept_tax_template( $location ) {
		$term = get_queried_object();

		if ( $term && ( $this->_cat_name == $term->taxonomy || $this->_tag_name == $term->taxonomy) ) {
			$location = get_query_template( 'archive', "archive-{$this->_cpt_name}.php");
		}
		return $location;
	}
	
	/**
	 * if the post doesn't have a featured image set
	 * adds a placeholder thumbnail from @link{http://placehold.it/}
	 * with the correct sizes.
	 *
	 * @global array $_wp_additional_image_sizes
	 * @param string $html
	 * @param int $post_id
	 * @param int $post_thumbnail_id
	 * @param string $size
	 * @param array $attr
	 * @return string
	 */
	public function dummy_thumbnail( $html, $post_id, $post_thumbnail_id, $size, $attr ) {
		global $_wp_additional_image_sizes;
		if ( ! $post_thumbnail_id && cr_get_option( 'post_default', false ) ) {
			$size_info = circleflip_get_size_dimensions( $size );
			$html = '<img src="' . cr_get_option('post_default')
					. '" style="width:' . $size_info['width'] . 'px'
					//. '; height:' . $size_info['height'] . 'px'
					. ';">';
		} else if ( $this->_cpt_name == get_post_type( $post_id )
					&& ! $post_thumbnail_id
					&& isset( $_wp_additional_image_sizes[ $size ] )
		) {
			$html = "<img src='http://placehold.it/"
					. "{$_wp_additional_image_sizes[ $size ]['width']}x"
					. "{$_wp_additional_image_sizes[ $size ]['height']}'>";
		}
		return $html;
	}

	/**
	 * add a More button to portfolio post types
	 *
	 * @return string
	 */
	public function excerpt_more() {
		$post = get_post();
		if ( $this->_cpt_name == get_post_type( $post ) ) {
			return "<a href='"
					. esc_url( apply_filters( 'the_permalink', get_permalink( $post ) ) )
					."' class='portOneLink postLink btnStyle1 red btnLarge'>More</a>";
		}
	}

	/**
	 * adds apropriate span* classes to each post depending on number of columns
	 * and adds all category/tag classes used for filtering by mixitup.js
	 *
	 * @param array $classes
	 * @param string $class
	 * @param int $post_id
	 * @return array
	 */
	public function handle_portfolio_columns( $classes, $class, $post_id ) {
		if ( $this->_cpt_name == get_post_type( $post_id ) ) {
			$columns = $this->get_columns_num();
			if ( 1 < $columns ) {
				$classes[] = 'span' . 12 / $columns;
			}
			$categories = $this->get_categories( $post_id, array('fields' => 'ids') );
			if ( $categories ) {
				// add all categories prefixed with category-
				$classes = array_merge( $classes, explode( ',', 'category-' . implode( ',category-', $categories ) ) );
			}
			$tags = $this->get_tags( $post_id, array('fields' => 'slugs') );
			if ( $tags ) {
				// add all tags prefixed with tag-
				$classes = array_merge( $classes, explode( ',', 'tag-' . implode( ',tag-', $tags ) ) );
			}

		}
		return $classes;
	}

	/**
	 * load the apropriate content-template based on number of columns
	 *
	 * @param string $template
	 * @return string
	 */
	public function columns_template( $template ) {
		$page_style = $this->get_page_style();

		$template = "portfolio-{$page_style}";

		if ( 'grid' == $page_style && 1 == $this->get_columns_num() ) {
			$template .= '-one-column';
		}
		return $template;
	}

	public function single_template( $template ) {
		$layout = circleflip_get_portfolio_meta(
					get_the_ID(),
					'layout',
					cr_get_option( "{$this->_cpt_name}-single-layout", 1 )
				);
		if ( 1 == $layout ) {
			$template = 'portfolio-layout1';
		} else {
			$template = 'portfolio-layout2';
		}
		return $template;
	}

		/**
	 * return the apropriate thumb size based on column number
	 *
	 * @param string $size
	 * @return string
	 */
	public function correct_image_size( $size ) {
		if ( $this->is_portfolio_page() && is_single() ) {
			$layout = circleflip_get_portfolio_meta(
				get_the_ID(),
				'layout',
				cr_get_option( "{$this->_cpt_name}-single-layout", 1 )
			);
			$size = 1 == $layout ? 'portfolio-full' : 'portfolio-side';
		} else if ( $this->is_portfolio_page() ) {
			$column_count = $this->get_columns_num();
			$style = $this->get_page_style();
			// single or two columns
			switch ( $column_count ) {
				case 2:
					$size = "portfolio-{$style}-two-column";
					break;
				case 3:
					$size = "portfolio-{$style}-three-column";
					break;
				case 4:
					$size = "portfolio-{$style}-four-column";
					break;
				default:
					// only happens in grid one column
					$size = "portfolio-{$style}-one-column";
			}
		}
		return $size;
	}

	public function correct_media_size( $size_info, $format_slug, $post_id, $size, $ident ) {
		if ( in_array( $format_slug, array('video', 'audio') ) && $this->is_portfolio_page() ) {
			if ( is_single() ) {
				$size_info = circleflip_get_size_dimensions( $this->correct_image_size( $size ) );
				if ( 'audio' == $format_slug ) 
					$size_info['height'] = 150;
			} else {
				$size_info['width'] = 640;
				$size_info['height'] = 360;
			}
		}
		return $size_info;
	}

	public function modify_query( &$query ) {
		if ( $query->is_tax( $this->_cat_name ) ) {
			$q_obj = $query->get_queried_object();
			$this->l10n['category'] = ".category-{$q_obj->slug}";
			$this->l10n['tag'] = '';
		} else if ( $query->is_tax( $this->_tag_name ) ) {
			$q_obj = $query->get_queried_object();
			$this->l10n['category'] = '*';
			$this->l10n['tag'] = "tag-{$q_obj->slug}";
		} else if ( $query->is_post_type_archive( $this->_cpt_name ) ) {
			$this->l10n['category'] = '*';
			$this->l10n['tag'] = 'all';
			return;
		} else {
			//not port-cat, port-tag, or archive; bail
			return;
		}

		$query->tax_query->queries = array();
		$query->is_tax = false;
		$query->is_post_type_archive = true;
		$query->queried_object = get_post_type_object( $this->_cpt_name );
		$query->queried_object_id = 0;

		if ( ! empty( $query->query_vars[$this->_cat_name] ) ) {
			unset( $query->query_vars[$this->_cat_name] );
		} else if ( ! empty( $query->query_vars[$this->_tag_name] ) ) {
			unset( $query->query_vars[$this->_tag_name] );
		}
		// unset( $query->queried_object_id );
		$query->query_vars['post_type'] = $this->_cpt_name;
		$query->query_vars['posts_per_page'] = -1;
	}

	public function handle_post_formats( $media_html, $format_slug, $post_id, $size, $ident, $audiovideo ) {
		if( $this->is_portfolio_page() && ! is_single() ) {
			global $wp_the_query;
			$page_id = !empty($wp_the_query->post) ? $wp_the_query->post->ID : 0;
			$post = get_post( $post_id );
			ob_start();
			?>

			<?php $portfolio_page_meta = circleflip_get_portfolio_page_meta($page_id); ?>
			<?php $media_icons = array("video"=>"icon-play","audio"=>"icon-note-beamed","gallery"=>"icon-picture");?>
			
			<!-- Pretty photo cases -->
			<?php $hover_classes= array("1"=>"zoomStyle3","2"=>"zoomRecent","3"=>"zoomPort","4"=>"");?>
			<?php $unique_var = uniqid() . mt_rand() ?>
			<?php if($format_slug == 'video'){
				$popup_zoom = '<a href="#'.$post_id.'-'.$unique_var.'" rel="prettyPhoto" class="'.$hover_classes[$portfolio_page_meta['hover-style']].' icon-play"></a>';
				$popup_html ='
				<div id="'.$post_id.'-'.$unique_var.'" class="hide">
					<div>
						'.$media_html.'
					</div>
				</div>';
			}elseif($format_slug == 'audio'){
				$popup_zoom = '<a href="#'.$post_id.'-'.$unique_var.'" rel="prettyPhoto" class="'.$hover_classes[$portfolio_page_meta['hover-style']].' icon-note-beamed"></a>';
				$popup_html ='
				<div id="'.$post_id.'-'.$unique_var.'" class="hide">
					<div>
						'.$media_html.'
					</div>
				</div>';
			}elseif($format_slug == 'gallery'){
				$meta = get_post_meta( $post_id, '_circleflip_post_formats', true);
				$gallery_ids = isset($meta['gallery']) ? $meta['gallery'] : array();//get all the gallery images ids
				$first_image_full = wp_get_attachment_image_src( $gallery_ids[0], 'full');//Get First image of gallery
				$first_image_full = $first_image_full[0];
				$popup_zoom = '<a href="'.$first_image_full.'" rel="prettyPhoto[pp_gal_'.$post_id.'-'.$unique_var.']" class="'.$hover_classes[$portfolio_page_meta['hover-style']].' icon-picture"></a>';
				$popup_html = '
				<div id="<?php echo $post_id ?>-<?php echo $unique_var ?>" class="hide">
					<div>';
						foreach ($gallery_ids as $key => $value) {
							if($key!=0){
								$image_pretty_full = wp_get_attachment_image_src( $value, 'full' );
								$image_pretty_full = $image_pretty_full[0];
								$popup_html .= '<a href="'.$image_pretty_full.'" rel="prettyPhoto[pp_gal_'.$post_id.'-'.$unique_var.']"></a>';
							}
						};
				$popup_html .= '
					</div>
				</div>';
			} ?>
			<!-- Pretty photo cases End -->
			
			<?php if($portfolio_page_meta['hover-style'] == 1): ?>
				<div class="portfolio3Img">
					<!-- IMAGE -->
					<?php the_post_thumbnail( $size ) ?>
					<!-- HOVER CONTAINER -->
					<div class="portfolio3Cont">
						<div class="portfolio3Cont2">
							<div class="portfolio3Cont2Inner">
								<?php if(($portfolio_page_meta['text_position'] == 'in') && ($portfolio_page_meta['columns'] != 1)){ ?>
								<a href="<?php the_permalink() ?>"><p class="portfolio3Title"><?php the_title(); ?></p></a>
								<?php } ?>
								<div class="ZoomContStyle3">
									<?php
									if ( 'standard' == $format_slug && has_post_thumbnail( $post_id ) ) {
										$image_id = get_post_thumbnail_id( $post_id );
										$image_full = wp_get_attachment_image_src( $image_id, 'full' );
										$src = $image_full[0];
										echo "<a href='$src' class='zoomStyle3' rel='prettyPhoto'></a>";
									} else if ( in_array( $format_slug, array( 'gallery', 'audio', 'video' ) ) ) {
										echo $popup_zoom;
										echo $popup_html;
									}
									?>
									<a href="<?php the_permalink() ?>" class="linkStyle3"></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			<?php elseif ( 2 == $portfolio_page_meta['hover-style'] ) : ?>
				<div class="squarePostImg">
					<div class="squarePostCont" style="background-color: rgba(227, 40, 49, 0.8);">
						<div class="squareAlignMid">
							<div class="squareAlignMid2">
								<?php if(($portfolio_page_meta['text_position'] == 'in') && ($portfolio_page_meta['columns'] != 1)){ ?>
								<a href="<?php the_permalink() ?>"><p class="squarePostTitle"><?php the_title(); ?></p></a>
								<?php } ?>
								<div class="linkZoomCont">
									<?php
									if ( 'standard' == $format_slug && has_post_thumbnail( $post_id ) ) {
										$image_id = get_post_thumbnail_id( $post_id );
										$image_full = wp_get_attachment_image_src( $image_id, 'full' );
										$src = $image_full[0];
										echo "<a href='$src' class='zoomRecent' rel='prettyPhoto'></a>";
									} else if ( in_array( $format_slug, array( 'gallery', 'audio', 'video' ) ) ) {
										$this->_media_queue[$post_id] = array('format' => $format_slug, 'content' => $media_html);
										echo $popup_zoom;
										echo $popup_html;
									}
									?>
									<a href="<?php the_permalink() ?>" class="linkRecent"></a>
								</div>
							</div>
						</div>
					</div>
					<?php the_post_thumbnail( $size ) ?>
				</div>
			<?php elseif($portfolio_page_meta['hover-style'] == 3):?>
				<div class="itemImageWrap">
					<!-- IMAGE -->
					<div>
						<?php the_post_thumbnail( $size ) ?>
					</div>
					<!-- HOVER CONTAINER -->
					<div class="portfolioHoverCont">
						<!-- TITLE -->
						<div class="alignMid1">
							<div class="alignMid2">
								<a href="<?php the_permalink() ?>"><p class="portHoverTitle"><?php the_title(); ?></p></a>
							</div>
						</div>
						<!-- ZOOM & LINK -->
						<?php
						if ( 'standard' == $format_slug && has_post_thumbnail( $post_id ) ) {
							$image_id = get_post_thumbnail_id( $post_id );
							$image_full = wp_get_attachment_image_src( $image_id, 'full' );
							$src = $image_full[0];
							echo "<a href='$src' class='zoomPort' rel='prettyPhoto'></a>";
						} else if ( in_array( $format_slug, array( 'gallery', 'audio', 'video' ) ) ) {
							$this->_media_queue[$post_id] = array('format' => $format_slug, 'content' => $media_html);
							echo $popup_zoom;
							echo $popup_html;
						}
						?>
						<a href="<?php the_permalink() ?>" class="linkPort" ></a>
					</div>
				</div>
			<?php else: ?>
				<!-- IMAGE -->
				<div>
					<?php the_post_thumbnail( $size ) ?>
				</div>
				<!-- HOVER CONTAINER -->
				<div class="hoverStyleNew">
					<a href="<?php the_permalink() ?>"><p class="portfolioNewTitle"><?php the_title(); ?></p></a>
					<p class="date"><?php echo get_the_date( 'M d, Y' ) ?> </p>
					<div class="category">
						<?php
							$options_categories = array();
							$port_cats = circleflip_get_portfolio_categories( $post->ID );
							if ( $port_cats ) {
								foreach ( $port_cats as $cat ) {
									$options_categories[$cat->term_id] = '<a href="'
											. get_term_link( $cat )
											. '" class="circleflip-portfolio-filter" data-dimension="category" data-filter=".category-' . $cat->term_id . '">'.$cat->name.'</a>';
								}
							}
						?>

						<?php if ( $options_categories ) : ?>
						<span><?php echo implode( '<span> | </span>', $options_categories ); ?></span>
						<?php endif; ?>
					</div>

					<p class="excerpt">
					<?php echo circleflip_string_limit_characters(get_the_content(),111); ?>
					</p>

					<a href="<?php echo get_permalink(); ?>" class="readmore"><?php _e('Details','circleflip'); ?> <span class="icon-right-open"></span></a>

				</div>
				
			<?php endif; ?>
			<?php if(($portfolio_page_meta['text_position'] == 'under') && ($portfolio_page_meta['columns'] != 1)): ?>
				<?php
				$options_categories = array();
				$port_cats = circleflip_get_portfolio_categories( $post->ID );
				if ( $port_cats ) {
					foreach ( $port_cats as $cat ) {
						$options_categories[$cat->term_id] = '<a href="'
								. get_term_link( $cat )
								. '" class="circleflip-portfolio-filter" data-dimension="category" data-filter=".category-' . $cat->term_id . '">'.$cat->name.'</a>';
					}
				}
				?>
				<div class="text_under_post clearfix">
					<h3><?php the_title(); ?></h3>
					<div class="date_cat">
					<p class="date"><?php echo get_the_date( 'M d, Y' ) ?> </p>
					<?php if ( $options_categories ) : ?>
					<span><?php echo implode( '<span>, </span>', $options_categories ); ?></span>
					<?php endif; ?>
					</div>
					<p class="excerpt">
					<?php echo circleflip_string_limit_characters(get_the_content(),200); ?>
					</p>
					<br />
					<a href="<?php echo get_permalink(); ?>" class="readmore">Read More &raquo;</a>
				</div>
			<?php endif; ?>
			<?php
			$media_html = ob_get_clean();
		}
		return $media_html;
	}

	function gallery_layout( $meta, $format_slug, $post_id, $size, $ident ) {
		if ( $this->is_portfolio_page() && ! is_single() && 'gallery' == $format_slug ) {
			$meta['gallery_layout'] = 'layout4';
		}
		return $meta;
	}

}

