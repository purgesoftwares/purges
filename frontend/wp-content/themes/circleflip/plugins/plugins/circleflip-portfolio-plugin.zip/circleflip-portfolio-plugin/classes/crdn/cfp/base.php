<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of base
 *
 * @author ayman
 */
class CRDN_CFP_Base {

	protected $_cpt_name = 'circleflip-portfolio';
	protected $_cat_name = 'circleflip-portfolio-cats';
	protected $_tag_name = 'circleflip-portfolio-tags';

	public function __construct() {
		// initialization filters
		add_action( 'init', array( $this, 'register_cpt' ) );
		add_action( 'init', array( $this, 'register_tax' ) );
		add_action( 'init', array( $this, 'register_scripts' ) );
		add_action( 'init', array( $this, 'register_img_sizes' ) );
		register_activation_hook( CRDN_CFP_ROOT, array( $this, 'activation' ) );
		register_deactivation_hook( CRDN_CFP_ROOT, array( $this, 'deactivation' ) );
		
		// Custom slug filters
		add_filter( 'circleflip_theme_options_pages_settings', array( $this, 'add_settings' ) );

		add_filter( 'circleflip_portfolio_register_post_type_args', array( $this, 'override_rewrite_slug' ) );
		
		$of_config = get_option( 'optionsframework' );
		$option_id = isset( $of_config['id'] ) ? $of_config['id'] : 'rojo';
		add_action( "update_option_$option_id", array( $this, 'flush_rewrite_slug' ), 10, 2 );
		add_action( "add_option_$option_id", array( $this, 'flush_rewrite_slug' ), 10, 2 );
		
		add_filter( 'circleflip_of_sanitize_text', array( $this, 'sanitize_rewrite_slug' ), 10, 2 );
		
	}

	public function activation() {
		$this->register_cpt();
		$this->register_tax();
		flush_rewrite_rules();
	}

	public function deactivation() {
		flush_rewrite_rules();
	}

		/**
	 * registers custom settings page in theme-options under pages settings
	 *
	 * @param array $options
	 * @return array $options after adding portfolio config options
	 */
	public function add_settings( $options ) {
		
		$options[] = array(
			'name'       => __( 'Portfolio Settings', 'options_framework_theme' ),
			'class'      => 'sub_heading',
			'type'       => 'heading',
			'icon_name'  => get_template_directory_uri() . '/creiden-framework/inc/images/sub.png',
		);
		
		$options[] = array(
			'name'	 => __( 'Portfolio Slug', 'options_framework_theme' ),
			'desc'	 => __( 'Used as base for portfolio related URLs', 'options_framework_theme' ),
			'id'	 => "{$this->_cpt_name}-rewrite-slug",
			'class'	 => 'mini',
			'std'	 => '',
			'type'	 => 'text'
		);

		return $options;
	}
	
	/** override portfolio base slug with user given slug
	 * 
	 * @hooked circleflip_portfolio_register_post_type_args
	 * @since 1.1
	 * @param array $args
	 * @return array
	 */
	public function override_rewrite_slug( $args ) {
		$portfolio_rewrite_slug = cr_get_option( "{$this->_cpt_name}-rewrite-slug", false );
		if ( $portfolio_rewrite_slug ) {
			if ( ! empty( $args['rewrite'] ) && is_array( $args['rewrite'] ) ) {
				$args['rewrite']['slug'] = $portfolio_rewrite_slug;
			} else {
				$args['rewrite'] = array( 'slug' => $portfolio_rewrite_slug );
			}
		}
		return $args;
	}
	
	/** flush rewrite rules when base slug changes
	 * 
	 * @hooked update_option_{$option_id}
	 * @hooked add_option_{$option_id}
	 * @since 1.1
	 * @param mixed $ignore string option_name from add_option | old_value from update_option
	 * @param array $value
	 */
	public function flush_rewrite_slug( $ignore, $value ) {
		$portfolio_post_type_obj = get_post_type_object( $this->_cpt_name );
		// make sure we have a user slug and its different from the current slug
		if ( $value["{$this->_cpt_name}-rewrite-slug"] 
				&& $portfolio_post_type_obj->rewrite['slug'] !== $value["{$this->_cpt_name}-rewrite-slug"] ) {
			// update rewrite rules
			$this->register_cpt();
			flush_rewrite_rules();
		}
	}
	
	/** sanitize user given slug
	 * 
	 * @since 1.1
	 * @param string $value
	 * @param array $option
	 * @return string
	 */
	public function sanitize_rewrite_slug( $value, $option ) {
		if ( "{$this->_cpt_name}-rewrite-slug" === $option['id'] ) {
			return sanitize_key( $value );
		}
		return $value;
	}

	/**
	 * registers portfolio custom post type
	 *
	 */
	public function register_cpt() {
		$labels = array(
			'name'				 => __( 'Portfolio Items', 'crdn-cfp' ),
			'singular_name'		 => __( 'Portfolio Item', 'crdn-cfp' ),
			'add_new'			 => __( 'Add New', 'crdn-cfp' ),
			'add_new_item'		 => __( 'Add New Portfolio Item', 'crdn-cfp' ),
			'edit_item'			 => __( 'Edit Portfolio Item', 'crdn-cfp' ),
			'new_item'			 => __( 'New Portfolio Item', 'crdn-cfp' ),
			'view_item'			 => __( 'View Portfolio Item', 'crdn-cfp' ),
			'search_items'		 => __( 'Search Portfolio', 'crdn-cfp' ),
			'not_found'			 => __( 'No portfolio items found', 'crdn-cfp' ),
			'not_found_in_trash' => __( 'No portfolio items found in Trash', 'crdn-cfp' ),
			'parent_item_colon'	 => __( 'Parent Portfolio:', 'crdn-cfp' ),
			'menu_name'			 => __( 'Portfolio', 'crdn-cfp' ),
		);

		$args = array(
			'labels'				 => $labels,
			'hierarchical'			 => false,
			'supports'				 => array( 'title', 'editor', 'thumbnail', 'post-formats' ),
			'taxonomies'			 => array( $this->_cat_name, $this->_tag_name ),
			'public'				 => true,
			'show_ui'				 => true,
			'show_in_menu'			 => true,
			'show_in_nav_menus'		 => true,
			'publicly_queryable'	 => true,
			'exclude_from_search'	 => false,
			'has_archive'			 => true,
			'query_var'				 => true,
			'can_export'			 => true,
			'rewrite'				 => true,
			'capability_type'		 => 'post'
		);

		/** Filter the portfolio cpt registeration args.
		 * 
		 * @since 1.1
		 * 
		 * @param array $args argument list for register_post_type
		 */
		register_post_type( $this->_cpt_name, apply_filters( 'circleflip_portfolio_register_post_type_args', $args ) );
	}

	/**
	 * registers both category and tag custom taxonomies
	 * for portfolio custom post type
	 *
	 * @todo disable public access
	 */
	public function register_tax() {
		$cat_args = array(
			'public'		 => true,
			'show_ui'		 => true,
			'query_var'		 => true,
			'hierarchical'	 => true,
			'labels'		 => array(
				'name'						 => __( 'Categories', 'crdn-cfp' ),
				'singular_name'				 => __( 'Category', 'crdn-cfp' ),
				'menu_name'					 => __( 'Categories', 'crdn-cfp' ),
				'search_items'				 => __( 'Search Categories', 'crdn-cfp' ),
				'popular_items'				 => __( 'Popular Categories', 'crdn-cfp' ),
				'all_items'					 => __( 'All Categories', 'crdn-cfp' ),
				'edit_item'					 => __( 'Edit Category', 'crdn-cfp' ),
				'update_item'				 => __( 'Update Category', 'crdn-cfp' ),
				'add_new_item'				 => __( 'Add New Category', 'crdn-cfp' ),
				'new_item_name'				 => __( 'New Category Name', 'crdn-cfp' ),
				'separate_items_with_commas' => __( 'Separate categories with commas', 'crdn-cfp' ),
				'add_or_remove_items'		 => __( 'Add or remove Categories', 'crdn-cfp' ),
				'choose_from_most_used'		 => __( 'Choose from the most popular Categories', 'crdn-cfp' ),
			),
		);
		register_taxonomy( $this->_cat_name, $this->_cpt_name, $cat_args );

		$tag_args = array(
			'public'	 => true,
			'show_ui'	 => true,
			'query_var'	 => true,
			'labels'	 => array(
				'name'						 => __( 'Tags', 'crdn-cfp' ),
				'singular_name'				 => __( 'Tag', 'crdn-cfp' ),
				'menu_name'					 => __( 'Tags', 'crdn-cfp' ),
				'search_items'				 => __( 'Search Tags', 'crdn-cfp' ),
				'popular_items'				 => __( 'Popular Tag', 'crdn-cfp' ),
				'all_items'					 => __( 'All Tags', 'crdn-cfp' ),
				'edit_item'					 => __( 'Edit Tag', 'crdn-cfp' ),
				'update_item'				 => __( 'Update Tag', 'crdn-cfp' ),
				'add_new_item'				 => __( 'Add New Tag', 'crdn-cfp' ),
				'new_item_name'				 => __( 'New Tag Name', 'crdn-cfp' ),
				'separate_items_with_commas' => __( 'Separate tags with commas', 'crdn-cfp' ),
				'add_or_remove_items'		 => __( 'Add or remove Tags', 'crdn-cfp' ),
				'choose_from_most_used'		 => __( 'Choose from the most popular Tags', 'crdn-cfp' ),
			),
		);
		register_taxonomy( $this->_tag_name, $this->_cpt_name, $tag_args );
	}

	/**
	 * registers all scripts available for portfolio pages
	 */
	public function register_scripts() {
		// metabox js
		wp_register_script(
			'circleflip-portfolio-admin',
			get_template_directory_uri() . '/inc/cpt/portfolio/js/admin.js',
			array('jquery', 'underscore', 'jquery-effects-slide')
		);
		// helper library
		wp_register_script(
			'jquery-mixitup',
			 get_template_directory_uri() . '/js/jquery.mixitup.js',
			array('jquery')
		);
		wp_register_script('pretty',get_template_directory_uri() . '/js/prettyPhoto.js');
		// filtering js
		wp_register_script(
			'circleflip-portfolio-front',
			get_template_directory_uri() . '/inc/cpt/portfolio/js/front.js',
			array('jquery', 'underscore', 'circleflip-isotope')
		);
		wp_register_script( 'masonrySectionJS', get_template_directory_uri() . '/scripts/modules/jquery.masonry.min.js' );
		wp_register_script( 'masonrySectionCustomJS', get_template_directory_uri() . '/scripts/modules/masonry.custom.js' );


		wp_register_style( 'portfolioStyle', get_template_directory_uri() . '/css/parts/portfolio-page.css', array('circleflip-style') );
		wp_register_style( 'prettyStyle', get_template_directory_uri() . '/css/prettyphoto/style/prettyPhoto.css', array('circleflip-style') );
	}
	
	/**
	 * registers image sizes used in all portfolio related pages
	 */
	public function register_img_sizes() {
		add_image_size( 'portfolio-checkers-one-column'  , 770, 400, true );
		
		// Grid sizes
		add_image_size( 'portfolio-grid-one-column', 570, 0, true );
		add_image_size( 'portfolio-grid-two-column'  , 570, 297, true );
		add_image_size( 'portfolio-grid-three-column', 370, 193, true );
		add_image_size( 'portfolio-grid-four-column' , 270, 270, true );

		// Masonry sizes
		add_image_size( 'portfolio-masonry-two-column'  , 570, 0, false );
		add_image_size( 'portfolio-masonry-three-column', 370, 0, false );
		add_image_size( 'portfolio-masonry-four-column' , 270, 0, false );

		// Single sizes
		add_image_size( 'portfolio-full', 1170, 0, true );
		add_image_size( 'portfolio-side', 770 , 0, true );
	}
	
	/* ======================================================================= *
	 *                             HELPER FUNCTIONS                            *
	 * ======================================================================= */

	/**
	 * get the number of columns set for this page type from theme-options
	 *
	 * @return int
	 */
	public function get_columns_num() {
		global $wp_the_query;
		$style = $this->get_page_style();
		if ( $wp_the_query->is_page() ) {
			$columns = circleflip_get_portfolio_page_meta( $wp_the_query->post->ID, 'columns' );
		} else {
			$columns = cr_get_option( "{$this->_cpt_name}-archive-columns", 1 );
		}

		if ( 'checkers' == $style && 1 < $columns ) { // checkers are only 1 column
			$columns = 1;
		} else if ( 'masonry' == $style && 1 == $columns ) { // masonry must be multiple columns
			$columns = 2;
		}
		return ( int ) $columns;
	}

	public function is_portfolio_page() {
		return is_tax( $this->_cat_name )
				|| is_tax( $this->_tag_name )
				|| is_post_type_archive( $this->_cpt_name )
				|| is_singular( $this->_cpt_name )
				|| is_page_template( 'templates/template-portfolio.php' );

//		return is_post_type_archive( $this->_cpt_name ) || is_singular( $this->_cpt_name );
	}

	/**
	 * gets metadata saved from `Portfolio Meta` metabox
	 *
	 * @param int $post_id
	 * @return array
	 */
	public function get_meta( $post_id ) {
		$raw_meta = get_post_meta( $post_id, "_{$this->_cpt_name}-meta", true );
		return wp_parse_args( $raw_meta, array(
			'layout'				 => 1,
			'project_details'		 => array(),
			'project_details_title'	 => __( 'Project Details', 'crdn-cfp' ),
				) );
	}

	public function get_page_meta( $page_id ) {
		$raw_meta = get_post_meta( $page_id, "_{$this->_cpt_name}-meta", true );
		return wp_parse_args( $raw_meta, array(
			'hover-style'	 => 1,
			'sidebar'		 => 'none',
			'which_sidebar'	 => '',
			'style'			 => 'grid',
			'columns'		 => 3,
			'text_position' => '',
				) );
	}

	public function get_page_style() {
		global $wp_the_query;
		if ( $wp_the_query->is_page() ) {
			$style = circleflip_get_portfolio_page_meta( $wp_the_query->post->ID, 'style', 'grid' );
		} else {
			$style = 'checkers';
		}
		return $style;
	}
	/**
	 * if no post_id is provided , gets all available portfolio categories
	 * if post_id is set, gets categories linked with post_id
	 * param args is delegated to wp_get_object_terms only if post_id is set
	 *
	 * @param int (optional) $post_id
	 * @param int (optional) $args
	 * @return array of term objects
	 */
	public function get_categories( $post_id = null, $args = array() ) {
		if ( null === $post_id ) {
			return get_terms( $this->_cat_name );
		}
		return wp_get_object_terms( $post_id, $this->_cat_name, $args );
	}

	/**
	 * if no post_id is provided , gets all available portfolio tags
	 * if post_id is set, gets tags linked with post_id
	 * param args is delegated to wp_get_object_terms only if post_id is set
	 *
	 * @param int (optional) $post_id
	 * @param int (optional) $args
	 * @return array of term objects
	 */
	public function get_tags( $post_id = null, $args = array() ) {
		if ( null === $post_id ) {
			return get_terms( $this->_tag_name );
		}
		return wp_get_object_terms( $post_id, $this->_tag_name, $args );
	}

	public function get_portfolio_items( $opts ) {
		$args = wp_parse_args( $opts, array(
			'post_type'		 => $this->_cpt_name,
			'posts_per_page' => -1
				) );
		return get_posts( $args );
	}
}
