<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of class-cflip-manager-admin
 *
 * @author Soha Salem
 */
class Cflip_Offer_Manager_Admin {

    public function circleflip_offer_cpt() {

	$labels = array(
	    'name'			 => _x( 'Offers', 'Post Type General Name', 'text_domain' ),
	    'singular_name'		 => _x( 'Offer', 'Post Type Singular Name', 'text_domain' ),
	    'menu_name'		 => __( 'Offer', 'text_domain' ),
	    'parent_item_colon'	 => __( 'Parent Item:', 'text_domain' ),
	    'all_items'		 => __( 'All Items', 'text_domain' ),
	    'view_item'		 => __( 'View Item', 'text_domain' ),
	    'add_new_item'		 => __( 'Add New Item', 'text_domain' ),
	    'add_new'		 => __( 'Add New', 'text_domain' ),
	    'edit_item'		 => __( 'Edit Item', 'text_domain' ),
	    'update_item'		 => __( 'Update Item', 'text_domain' ),
	    'search_items'		 => __( 'Search Item', 'text_domain' ),
	    'not_found'		 => __( 'Not found', 'text_domain' ),
	    'not_found_in_trash'	 => __( 'Not found in Trash', 'text_domain' ),
	);
	$args = array(
	    'labels'		 => $labels,
	    'supports'		 => array( 'thumbnail', 'title', 'editor' ),
	    'taxonomies'		 => array(),
	    'hierarchical'		 => false,
	    'public'		 => true,
	    'show_ui'		 => true,
	    'show_in_menu'		 => true,
	    'show_in_nav_menus'	 => true,
	    'show_in_admin_bar'	 => true,
	    'menu_position'		 => 5,
	    'can_export'		 => true,
	    'has_archive'		 => true,
	    'exclude_from_search'	 => false,
	    'publicly_queryable'	 => true,
	    'capability_type'	 => 'page',
	);
	register_post_type( 'circleflip-offer', $args );
    }

    public function circleflip_offer_tax() {
	$cat_args = array(
	    'public'	 => true,
	    'show_ui'	 => true,
	    'query_var'	 => true,
	    'hierarchical'	 => true,
	    'labels'	 => array(
		'name'				 => __( 'Categories', 'crdn-cfp' ),
		'singular_name'			 => __( 'Category', 'crdn-cfp' ),
		'menu_name'			 => __( 'Categories', 'crdn-cfp' ),
		'search_items'			 => __( 'Search Categories', 'crdn-cfp' ),
		'popular_items'			 => __( 'Popular Categories', 'crdn-cfp' ),
		'all_items'			 => __( 'All Categories', 'crdn-cfp' ),
		'edit_item'			 => __( 'Edit Category', 'crdn-cfp' ),
		'update_item'			 => __( 'Update Category', 'crdn-cfp' ),
		'add_new_item'			 => __( 'Add New Category', 'crdn-cfp' ),
		'new_item_name'			 => __( 'New Category Name', 'crdn-cfp' ),
		'separate_items_with_commas'	 => __( 'Separate categories with commas', 'crdn-cfp' ),
		'add_or_remove_items'		 => __( 'Add or remove Categories', 'crdn-cfp' ),
		'choose_from_most_used'		 => __( 'Choose from the most popular Categories', 'crdn-cfp' ),
	    ),
	);
	register_taxonomy( 'circleflip-offer-category', 'circleflip-offer', $cat_args );
    }

    public function circleflip_enqueue_date_handle() {
	wp_register_script( 'cflip-offer-date', get_template_directory_uri() . '/js/cflip-offer-date-handle.js', array( 'jquery' ) );
	wp_enqueue_script( 'cflip-offer-date' );
    }

    public function circleflip_register_offer_metabox() {
	add_meta_box( 'circleflip-offer-mb', 'Offer Details', array( $this, 'circleflip_render_offer_metabox' ), 'circleflip-offer' );
    }

    public function circleflip_render_offer_metabox( $post ) {
	global $post;
	$offer_data = get_post_meta( $post->ID, 'cflip_offer_meta', true );
	wp_nonce_field( 'circleflip-offer', 'circleflip-offer[_nonce]' );
	?>
	<p>
	    <label>
		<b>Duration</b>
		<b>Start Date:</b>
		<input type="date" name='circleflip-offer[duration][start]' value="<?php echo $offer_data ? $offer_data['startDate'] : "" ?>" />
		<b>End Date:</b>
		<input type='date' name='circleflip-offer[duration][end]' value="<?php echo $offer_data ? $offer_data['endDate'] : "" ?>" />
	    </label>
	    <label>
		<b>Price</b>
		<input type='text' name='circleflip-offer[price]' value="<?php echo $offer_data ? $offer_data['price'] : "" ?>" />
	    </label>
	    <label>
		<b>Person</b>
		<input type='text' name="circleflip-offer[person]" value="<?php echo $offer_data ? $offer_data['person'] : "" ?>" />
	    </label>
	</p>
	<?php
    }

    function circleflip_save_offer_metabox( $post_id ) {
	if ( "circleflip-offer" != get_post_type( $post_id ) || ! isset( $_POST['circleflip-offer'] ) || ! wp_verify_nonce( $_POST['circleflip-offer']['_nonce'], 'circleflip-offer' )  || defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE || ! current_user_can( 'edit_post', $post_id ) ) {
	    return ;
	}

	$date1 = $_POST['circleflip-offer']['duration']['start'];
	$date2 = $_POST['circleflip-offer']['duration']['end'];

	if ( strtotime( $date1 ) > strtotime( $date2 ) ) {
	    return;
	}

	$offer_data = array(
	    'price'		 => $_POST['circleflip-offer']['price'],
	    'person'	 => $_POST['circleflip-offer']['person'],
	    'startDate'	 => $date1,
	    'endDate'	 => $date2
	);

	update_post_meta( $post_id, "cflip_offer_meta", $offer_data );
	return $post_id;
    }

    public function get_offer_items( $opts ) {
	$args = wp_parse_args( $opts, array(
	    'post_type'	 => 'circleflip-offer',
	    'posts_per_page' => -1
		) );
	return get_posts( $args );
    }

    public function get_offer_categories( $post_id = null, $args = array() ) {
	if ( null === $post_id ) {
	    return get_terms( 'circleflip-offer-category' );
	}
	return wp_get_object_terms( $post_id, 'circleflip-offer-category', $args );
    }

}
