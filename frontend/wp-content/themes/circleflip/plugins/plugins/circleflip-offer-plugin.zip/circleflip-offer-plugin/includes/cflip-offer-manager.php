<?php

class Cflip_Offer_Manager {

    protected $version;
    protected $loader;
    protected $plugin_slug;

    public function __construct() {
	$this->plugin_slug = 'cflip-offer-block-slug';
	$this->version = '0.1.0';

	$this->load_dependencies();
	$this->define_admin_hooks();
    }

    private function load_dependencies() {
	require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/cflip-offer-manager-admin.php';
	require_once plugin_dir_path( __FILE__ ) . 'circle-flip-offer-functions.php';
	require_once plugin_dir_path( __FILE__ ) . 'cflip-offer-loader.php';
	$this->loader = new Cflip_Offer_Manager_Loader();
    }

    private function define_admin_hooks() {
	$admin = new Cflip_Offer_Manager_Admin();
	$this->loader->add_action( 'init', $admin, 'circleflip_offer_cpt' );
	$this->loader->add_action( 'init', $admin, 'circleflip_offer_tax' );
	$this->loader->add_action( 'add_meta_boxes', $admin, 'circleflip_register_offer_metabox' );
	$this->loader->add_action( 'save_post', $admin, 'circleflip_save_offer_metabox' );
	$this->loader->add_action('admin_enqueue_scripts',$admin,'circleflip_enqueue_date_handle');
    }

    public function run() {
	$this->loader->run();
    }

}
