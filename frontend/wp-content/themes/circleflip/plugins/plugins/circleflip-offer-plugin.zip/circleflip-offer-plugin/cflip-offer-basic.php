<?php

/**
 * Plugin Name: CircleFlip Offer
 * Description: adds offer feature
 * Version: 1.1.0
 * Author: Creiden
 * Author URI: http://creiden.com
 * License: GPL2
 */
require_once plugin_dir_path( __FILE__ ) . 'includes/cflip-offer-manager.php';

function cflip_run_offer_plugin() {
    $cflip_offer = new Cflip_Offer_Manager();
    $cflip_offer->run();
}

cflip_run_offer_plugin();


